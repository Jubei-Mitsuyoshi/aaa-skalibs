/* ISC license. */

#include "skaclient.h"

skaclient_t const skaclient_zero = SKACLIENT_ZERO ;
