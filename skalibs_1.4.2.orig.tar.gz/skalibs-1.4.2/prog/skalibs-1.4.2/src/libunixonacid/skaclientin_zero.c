/* ISC license. */

#include "skaclient.h"

skaclientin_t const skaclientin_zero = SKACLIENTIN_ZERO ;
