/* ISC license. */

#include "uint32.h"
#include "fmtscan-internal.h"

SCANB0(32)
