/* ISC license. */

/* MT-unsafe */

#include "sgetopt.h"

subgetopt_t subgetopt_here = SUBGETOPT_ZERO ;
