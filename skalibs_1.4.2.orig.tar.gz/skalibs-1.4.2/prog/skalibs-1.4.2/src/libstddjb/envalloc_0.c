/* ISC license. */

#include "genalloc.h"
#include "envalloc.h"

int envalloc_0 (genalloc *v)
{
  char const *z = 0 ;
  return genalloc_append(char const *, v, &z) ;
}
