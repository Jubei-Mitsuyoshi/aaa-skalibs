/* ISC license. */

#include "genwrite.h"

int genwrite_flush_stralloc (void *target)
{
  (void)target ;
  return 1 ;
}
