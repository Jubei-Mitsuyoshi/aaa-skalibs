/* ISC license. */

#include "buffer.h"
#include "genwrite.h"

genwrite_t genwrite_stdout = GENWRITE_BUFFER_INIT(buffer_1) ;
