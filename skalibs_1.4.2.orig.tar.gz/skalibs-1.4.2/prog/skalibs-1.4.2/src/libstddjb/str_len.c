/* ISC license. */

#include "skalibs-config.h"

#ifdef SKALIBS_FLAG_REPLACE_LIBC

#include "bytestr.h"

unsigned int str_len (char const *s)
{
  register char const *t = s ;
  for (;;)
  {
    if (!*t) return t - s; ++t;
    if (!*t) return t - s; ++t;
    if (!*t) return t - s; ++t;
    if (!*t) return t - s; ++t;
  }
}

#endif
