/* ISC license. */

/* MT-unsafe */

#include "random.h"

int badrandom_init (void)
{
  return 1 ;
}
