/* ISC license. */

#include <sys/ioctl.h>
#include <termios.h>

int r = TIOCREMOTE ;
