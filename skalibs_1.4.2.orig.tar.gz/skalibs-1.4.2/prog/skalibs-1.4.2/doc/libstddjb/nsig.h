/* ISC license. */

#ifndef NSIG
# define NSIG 64
#endif
